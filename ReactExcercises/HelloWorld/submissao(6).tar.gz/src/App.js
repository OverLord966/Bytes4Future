import logo from './logo.svg';
import './App.css';
import HelloWorld from './HelloWorld';

function App() {
  return (
    <div className="App">
      <HelloWorld name="Maria" />
      <HelloWorld />
    </div>
  );
}

export default App;
