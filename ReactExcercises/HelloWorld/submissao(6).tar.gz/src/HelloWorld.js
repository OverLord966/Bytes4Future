export default function HelloWorld(props) {
  if (props.name === undefined) {
    return (
      <div>
        <h1>Hello, stranger. </h1>
      </div>
    );
  } else
    return (
      <div>
        <h1>Hello, {props.name}.</h1>
      </div>
    );
}
