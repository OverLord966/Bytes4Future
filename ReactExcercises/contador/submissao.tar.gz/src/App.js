import logo from './logo.svg';
import './App.css';
import Contador from './Contador'
function App() {
  return (
    <div className="App">
      <Contador/>
    </div>
  );
}

export default App;
