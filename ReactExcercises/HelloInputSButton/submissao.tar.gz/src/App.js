
import './App.css';
import HelloInput from './HelloInput';

function App() {
  return (
    <div className="App">
      <HelloInput></HelloInput>
    </div>
  );
}

export default App;