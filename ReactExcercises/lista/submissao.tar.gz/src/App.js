import logo from './logo.svg';
import './App.css';
import Lista from './lista';

function App() {
  return (
    <div className="App">
      <Lista/>
    </div>
  );
}

export default App;
